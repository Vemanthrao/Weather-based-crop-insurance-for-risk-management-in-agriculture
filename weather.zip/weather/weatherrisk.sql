CREATE DATABASE weatherrisk;

USE weatherrisk;

CREATE TABLE Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL
);

CREATE TABLE HistoricalWeatherData (
    id INT AUTO_INCREMENT PRIMARY KEY,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    analysis_result TEXT
);

CREATE TABLE CropRecommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crop_type VARCHAR(255) NOT NULL,
    recommendations TEXT
);

CREATE TABLE CropPerformanceData (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crop_type VARCHAR(255) NOT NULL,
    analysis_type VARCHAR(255) NOT NULL,
    analysis_results TEXT
);

CREATE TABLE DisasterPreparednessTips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tip TEXT NOT NULL
);

CREATE TABLE RiskManagementPlans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location VARCHAR(255) NOT NULL,
    soil_type VARCHAR(255) NOT NULL,
    crop_type VARCHAR(255) NOT NULL
);

CREATE TABLE SustainableFarmingAdvice (
    id INT AUTO_INCREMENT PRIMARY KEY,
    advice VARCHAR(255) NOT NULL
);
